import sqlite3
import random

# Create a SQLite database connection
conn = sqlite3.connect('uk_flights.db')
c = conn.cursor()

# Drop the currency_rates table if it exists, then recreate it
c.execute('''DROP TABLE IF EXISTS currency_rates''')
c.execute('''CREATE TABLE currency_rates (
                currency_code TEXT PRIMARY KEY,
                rate_against_gbp REAL
            )''')

# Define sample currency codes
currencies = ["USD", "EUR", "INR", "YEN"]

# Generate and insert random exchange rates for each currency
for currency in currencies:
    # Generate a random exchange rate for each currency against GBP
    # Assuming realistic ranges for demonstration purposes
    if currency == "USD":
        rate = round(random.uniform(1.2, 1.4), 2)  # Example range for USD to GBP
    elif currency == "EUR":
        rate = round(random.uniform(0.8, 0.9), 2)  # Example range for EUR to GBP
    elif currency == "INR":
        rate = round(random.uniform(90, 100), 2)   # Example range for INR to GBP
    elif currency == "YEN":
        rate = round(random.uniform(140, 150), 2)  # Example range for YEN to GBP

    c.execute('''INSERT INTO currency_rates (currency_code, rate_against_gbp)
                 VALUES (?, ?)''', (currency, rate))

# Commit changes and close connection
conn.commit()
conn.close()

print("Database file 'uk_flights.db' has been updated with currency rates.")
