import sqlite3
import random
from datetime import datetime, timedelta

# Create a SQLite database connection
conn = sqlite3.connect('uk_flights.db')
c = conn.cursor()

# Create the 'flights' table with a 'miscellaneous' column
c.execute('''DROP TABLE IF EXISTS flights''')  # Drops the existing table; remove this line to keep existing data
c.execute('''CREATE TABLE flights (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                origin TEXT,
                destination TEXT,
                airline TEXT,
                available_seats INTEGER,
                num_connections INTEGER,
                fare REAL,
                departure_date TEXT,
                miscellaneous TEXT  -- Column for miscellaneous information
            )''')

# Sample data for UK origin, destination, and airlines
cities = ["London", "Manchester", "Edinburgh", "Bristol"]
airlines = ["British Airways", "easyJet", "Ryanair", "Virgin Atlantic"]

# Generate 20 random flight data entries and insert into the table
for i in range(20):
    origin = random.choice(cities)
    destination = random.choice(list(set(cities) - {origin}))  # Ensure destination is different from origin
    airline = random.choice(airlines)
    available_seats = random.randint(50, 200)
    num_connections = random.randint(0, 2)
    fare = round(random.uniform(50.0, 300.0), 2)  # Assuming fare is in GBP
    departure_date = datetime.today() + timedelta(days=random.randint(1, 60))
    departure_date_str = departure_date.strftime('%Y-%m-%d')

    # Placeholder for miscellaneous information; could be links to more info
    misc_url = f"https://example.com/flight-info/{i+1}"

    c.execute('''INSERT INTO flights (origin, destination, airline, available_seats, num_connections, fare, departure_date, miscellaneous)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?)''',
                 (origin, destination, airline, available_seats, num_connections, fare, departure_date_str, misc_url))

# Commit changes and close connection
conn.commit()
conn.close()

print("Database 'uk_flights.db' has been updated with 20 rows of sample data, including UK cities, airlines, and miscellaneous links.")
