import requests
from flask import Flask, request, jsonify, render_template
import sqlite3
import logging

app = Flask(__name__)

def fetch_flights(origin=None, destination=None, direct_flight=None, currency='GBP'):
    conn = sqlite3.connect('uk_flights.db')
    c = conn.cursor()
    # Fetch the exchange rate for the selected currency
    c.execute("SELECT rate_against_gbp FROM currency_rates WHERE currency_code = ?", (currency,))
    rate = c.fetchone()
    exchange_rate = rate[0] if rate else 1  # Default to 1 if currency not found or GBP

    # Include the miscellaneous column in the query
    query = "SELECT id, origin, destination, airline, available_seats, num_connections, round(fare * ? ,2) as fare, departure_date, miscellaneous FROM flights"
    params = [exchange_rate]

    if origin:
        query += " WHERE origin=?"
        params.append(origin)
    if destination:
        if "WHERE" in query:
            query += " AND destination=?"
        else:
            query += " WHERE destination=?"
        params.append(destination)
    if direct_flight:
        if "WHERE" in query:
            query += " AND num_connections=0"
        else:
            query += " WHERE num_connections=0"

    c.execute(query, params)
    flights = c.fetchall()
    conn.close()
    return flights



@app.route('/', methods=['GET'])
def search_flights():
    origin = request.args.get('origin', '')
    destination = request.args.get('destination', '')
    direct_flight = request.args.get('direct_flight', '')
    currency = request.args.get('currency', 'GBP')

    flights = fetch_flights(origin, destination, direct_flight, currency)

    currency_symbols = {'GBP': '£', 'USD': '$', 'EUR': '€', 'INR': '₹', 'YEN': '¥'}
    currency_symbol = currency_symbols.get(currency, '')

    return render_template('flights.html', flights=flights, currency=currency, currency_symbol=currency_symbol, origin=origin, destination=destination, direct_flight=direct_flight)

@app.route('/booking', methods=['GET'])
def booking_page():
    flight_id = request.args.get('flight_id')
    return render_template('booking.html', flight_id=flight_id)

@app.route('/confirm_booking', methods=['POST'])
def confirm_booking():
    flight_id = request.form.get('flight_id')
    seats_booked = int(request.form.get('seats_booked'))

    conn = sqlite3.connect('uk_flights.db')
    c = conn.cursor()
    c.execute("SELECT available_seats FROM flights WHERE id = ?", (flight_id,))
    available_seats = c.fetchone()[0]

    if available_seats >= seats_booked:
        new_available_seats = available_seats - seats_booked
        c.execute("UPDATE flights SET available_seats = ? WHERE id = ?", (new_available_seats, flight_id))
        conn.commit()
        message = "Booking successful."
    else:
        message = "Not enough seats available."

    conn.close()
    return jsonify({'message': message})



if __name__ == '__main__':
    app.run(debug=True)
